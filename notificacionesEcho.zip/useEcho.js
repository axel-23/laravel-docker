import Echo from "laravel-echo";
import Pusher from "pusher-js";

let echoInstance = null;

export const createEcho = (token) => {
    if (!token) return null;

    if (echoInstance) {
        return echoInstance;
    }

    window.Pusher = Pusher;

    echoInstance = new Echo({
        broadcaster: "reverb",
        key: import.meta.env.VITE_REVERB_APP_KEY,
        wsHost: import.meta.env.VITE_REVERB_HOST,
        wsPort: import.meta.env.VITE_REVERB_PORT,
        wssPort: import.meta.env.VITE_REVERB_PORT,
        forceTLS: (import.meta.env.VITE_REVERB_SCHEME ?? "https") === "https",
        enabledTransports: ["ws", "wss"],
        authEndpoint: `${import.meta.env.VITE_APP_API_URL}/broadcasting/auth`,
        auth: {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        },
    });

    echoInstance.connector.pusher.connection.bind("connected", () => {
        console.log("WebSocket conectado a Reverb");
    });

    echoInstance.connector.pusher.connection.bind("disconnected", () => {
        console.log("WebSocket desconectado");
    });

    return echoInstance;
};

export const getEcho = () => {
    return echoInstance;
};

export const disconnectEcho = () => {
    if (echoInstance) {
        echoInstance.disconnect();
        echoInstance = null;
    }
};