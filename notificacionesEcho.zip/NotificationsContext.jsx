import { createContext, useContext, useEffect, useRef, useState } from "react";
import { createEcho, getEcho } from "@/hooks/useEcho";
import { fetchNotifications, markAllAsReadNotification, markAsReadNotification } from "@/services";
import { showToast } from "@/utils";
import { useAuth } from "@/context/AuthContext";
const NotificationsContext = createContext();

export const NotificationsProvider = ({ children }) => {
    const [notificaciones, setNotificaciones] = useState([]);
    const echoRef = useRef(null);
    const { auth } = useAuth();

    const token = auth?.token;
    const userId = auth?.user?.id_usuario;

    const fetchNotificationsService = async (params) => {
        try {
            const { status, data } = await fetchNotifications(params);
            if (status === 200) {
                setNotificaciones(data);
            }
        } catch (error) {
            console.error("Error al obtener notificaciones:", error);
        }
    };

    const markAsRead = async (id, params) => {
        const { status, data } = await markAsReadNotification(id, params);
        if (status === 200) {
            showToast("success", "Éxito", "Notificación marcada como leída");
            setNotificaciones(data);
        }
    };

    const markAllAsRead = async (params) => {
        const { status, data } = await markAllAsReadNotification(params);
        if (status === 200) {
            showToast("success", "Éxito", "Notificaciones marcadas como leídas");
            setNotificaciones(data);
        }
    };

    const getNotifications = () => {
        try {
            if (!notificaciones) return [];
            return {
                notifications: notificaciones?.data,
                total_items: notificaciones?.total_items,
                total_unread: notificaciones?.total_unread,
                total_pages: notificaciones?.total_pages
            };
        } catch {
            return [];
        }
    };

    /**
     * Crear conexión Echo cuando exista token
     */
    useEffect(() => {
        if (!token) return;

        createEcho(token);

    }, [token]);

    /**
     * Suscribirse a canales cuando exista echo y user
     */
    useEffect(() => {
        const echo = getEcho();

        if (!echo || !userId) return;

        echo.channel("public-messages")
            .listen(".message.sent", (event) => {
                console.log("Notificación pública:", event);
            });

        echo.private(`private-notification.${userId}`)
            .listen(".private-notification.sent", (event) => {
                console.log("Notificación privada:", event);
                fetchNotificationsService();
            });

        return () => {
            echo.leave("public-messages");
            echo.leave(`private-notification.${userId}`);
        };

    }, [userId]);

    return (
        <NotificationsContext.Provider
            value={{
                getNotifications,
                fetchNotificationsService,
                markAsRead,
                markAllAsRead
            }}
        >
            {children}
        </NotificationsContext.Provider>
    );
};

export const useNotificationsContext = () => useContext(NotificationsContext);