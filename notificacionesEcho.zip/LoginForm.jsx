import { Button } from "primereact/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router";

import { loginSchema } from "../schemas";
import { Input, InputPassword, Title } from "@components";
import { login } from "@services";
import { useAuth } from "@/context/AuthContext";
import useAuth2FA from "@/hooks/useAuth2FA";
import { useLoader } from "@/context/LoaderContext";
import { useLoginStore } from "@/stores";

const LoginForm = () => {
  const { setAuth } = useAuth();
  const { setAuth2FA } = useAuth2FA();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: zodResolver(loginSchema), mode: "onChange" });
  const { showLoader, hideLoader } = useLoader();
  const { setRecover, setSetup2FA, setCode2FA } = useLoginStore();

  const navigate = useNavigate();

  const onLogin = async (data) => {
    try {
      showLoader();
      const res = await login(data?.email, data?.password);
      if(res?.data?.password_changed === false){
        setAuth(res.data);
        navigate("/cambiar-contrasena")
        return
      }
      if (res.data?.is_enabled && res.data?.has_secret) {
        setAuth2FA(res.data);
        navigate("/codigo-factor")
      } else if (!res.data?.has_secret && res.data?.is_enabled) {
        setAuth2FA(res.data);
        setSetup2FA();
      } else {
        setAuth(res.data);
        navigate("/");
      }
    } catch (e) {
      logIfDev(e);
    } finally {
      hideLoader();''
    }
  };

  return (
    <form
      onSubmit={handleSubmit(onLogin)}
      className="flex w-full sm:w-[85%] items-center flex-col gap-4"
    >
      <Title className text="Iniciar sesión" />
      <Input
        startIcon="person"
        id="email"
        {...register("email")}
        name="email"
        label="Correo electrónico"
        errors={errors}
      />
      <InputPassword
        startIcon="lock"
        id="password"
        {...register("password")}
        name="password"
        label="Contraseña"
        errors={errors}
      />
      <Button label="Ingresar" type="submit" />
      <div className="flex justify-center">
        <button onClick={setRecover}>
          <p className="underline underline-offset-2">Recuperar contraseña</p>
        </button>
      </div>
    </form>
  );
};

export default LoginForm;
