import { createContext, useContext, useEffect, useState } from "react";
import { deserializeStore, serializeStore } from "@/utils/serialize";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [auth, setAuthState] = useState(null);

    useEffect(() => {
        const stored = localStorage.getItem("auth");

        if (stored) {
            const parsed = JSON.parse(stored);
            setAuthState(deserializeStore(parsed));
        }
    }, []);

    const setAuth = (data) => {
        const serialized = serializeStore(data);
        localStorage.setItem("auth", JSON.stringify(serialized));
        setAuthState(data);
    };

    const logout = () => {
        localStorage.removeItem("auth");
        setAuthState(null);
        window.location.href = "/login";
    };

    return (
        <AuthContext.Provider
            value={{
                auth,
                setAuth,
                logout,
                isLogged: !!auth?.token
            }}
        >
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);