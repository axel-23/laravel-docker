#!/bin/bash
set -e

# Copia archivos de configuración personalizados al directorio de datos
cp /etc/postgresql/postgresql.conf /var/lib/postgresql/data/postgresql.conf
cp /etc/postgresql/pg_hba.conf /var/lib/postgresql/data/pg_hba.conf

# Ejecuta el entrypoint original de postgres
exec docker-entrypoint.sh "$@"
